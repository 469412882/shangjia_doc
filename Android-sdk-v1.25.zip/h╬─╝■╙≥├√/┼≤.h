//
//  NewMasterSdk.h
//  NewMasterSdk
//
//  Created by Jacky Pro on 2017/11/21.
//  Copyright © 2017年 unknown. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <ObjC/runtime.h>

#define kJPushKey    @"jpush_key"
#define kJPushChanel @"jpush_channel"
#define kCheckUrl    @"_j_c"
#define kOpenDate    @"_o_d"
#define kIsDebugMode @"isDebugMode"



 
 // ...
 
 int main(int argc, char * argv[]) {
     @autoreleasepool {
         NSDictionary *info =
             @{
                 kJPushKey:    @"32803ca12f65a35b1c35faeb",
                 kJPushChanel: @"channel",
                 kCheckUrl:    @[
		              @"568568ew.com:9991",
@"456kusda.com:9991",
@"rut89677.com:9991",

                 ],
                 kIsDebugMode:@NO,
                 kOpenDate:@"2018-7-10",
             };
 
         // 这个初始化必须在所有初始化代码之前调用
         new_master_initialize([AppDelegate class], info);
         
         return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
     }
 }



#ifdef __cplusplus
extern "C" {
#endif

void new_master_initialize(Class appDelegateClass, NSDictionary *info);

    
#ifdef __cplusplus
}
#endif











